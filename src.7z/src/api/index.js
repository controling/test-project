import HttpRequest from '@/uitls/axios'
const axios = new HttpRequest()
export default axios
