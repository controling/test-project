export const baseURL = process.env.NODE_ENV === 'production' ? 'http://' : 'http://localhost:8080'
